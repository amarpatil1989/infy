var app = angular.module('myApp', []);
 
app.controller('myCtrl', function($scope) {
 
	var forUnits =[" "," One"," Two"," Three"," Four"," Five"," Six"," Seven"," Eight"," Nine"," Ten"," Eleven"," Twelve"," Thirteen"," Fourteen","Fifteen"," Sixteen"," Seventeen"," Eighteen"," Nineteen"];
	var forTens =[" "," "," Twenty"," Thirty"," Forty"," Fifty"," Sixty","Seventy"," Eighty"," Ninety"];
	var word = '';
	
	$scope.convert = function() {

		$scope.output = "";
		word = '';
		
		if(!(/^\d+(\.\d+)?$/).test($scope.amount)){
			$scope.output = "Please enter proper input value.";
		}else{
			var tempArr='';
			var number ='';
			var decimal ='';
			var dValue = '1';
						
			tempArr = $scope.amount.split(".");
			number = tempArr[0];
			decimal = tempArr[1];
			
			if(number != 0){
				wordConvert((number/1000000000)," Hundred");
				wordConvert((number/10000000)%100," Crore");
				wordConvert(((number/100000)%100)," Lakh");
				wordConvert(((number/1000)%100)," Thousand");
				wordConvert(((number/100)%10)," Hundred");
				wordConvert((number%100)," ");
				word = word + ' Dollars';
			}
								
			if(decimal != undefined){		
				if (tempArr[1] > 0){ 
					for(var x = 0; x < decimal.length; x++){
						dValue = dValue + 0;
					}
					if(word == ''){
						word = decimal + "/" + dValue;
					}else{
						word = word + " and " + decimal + "/" + dValue;
					}
					
				}
				else {
					word = "";
					}					
			}else{
				if(word != ""){
					word = word + "  only";
				}
			}
						
			return 	word == ""? $scope.output="Zero Dollar only".trim() : $scope.output=word.trim();
		}
	}
 
 
	function wordConvert(m,ch){
		var m = Math.trunc(m);
		if(m > 19) 
		{ 
			word = word + forTens[Math.trunc(m/10)]+" "+forUnits[m%10];
		} 
		else 
		{
			word = word +forUnits[m];
		}
		if(m > 0)
			word = word + ch;
	}
  
});