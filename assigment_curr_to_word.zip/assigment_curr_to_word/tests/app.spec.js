describe('Test Controller', function() {
    beforeEach(angular.mock.module('myApp'));
	var $controller, $scope, controller;

  beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
  }));
    
    beforeEach(function() {
      $scope = {};
      controller = $controller('myCtrl', { $scope: $scope });
    });

    it('it should return One Hundred Twenty Three Dollars only if the input number is 111', function() {
      $scope.inputNumber = '111';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('One Hundred Twenty Three Dollars only');
    });

    it('it should return Twelve Crore Thirty Four Lakh Fifty Six Thousand Seven Hundred Eighty Nine Dollars only if the input number is 123456789', function() {
      $scope.inputNumber = '123456789';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('Twelve Crore Thirty Four Lakh Fifty Six Thousand Seven Hundred Eighty Nine Dollars only');
    });
	
	it('it should return Seven Hundred Eighty Nine Dollars and 99/100 if the input number is 789.99', function() {
      $scope.inputNumber = '789.99';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('Seven Hundred Eighty Nine Dollars and 99/100');
    });
	
	it('it should return Fifty Five Dollars and 626262/1000000 if the input number is 55.626262', function() {
      $scope.inputNumber = '55.626262';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual(' Fifty Five Dollars and 626262/1000000');
    });
	
	it('it should return Zero Dollar if the input number is 0.0', function() {
      $scope.inputNumber = '0.0';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('Zero Dollar only');
    });
	
	it('it should return "Please enter proper input value." if the input number is .5', function() {
      $scope.inputNumber = '.5';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual("Please enter proper input value.");
    });	
	
	it('it should return "Please enter proper input value." if the input number is -123', function() {
      $scope.inputNumber = '-123';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual("Please enter proper input value.");
    });	
	
	it('it should return "Please enter proper input value." if the input number is 45.56.14', function() {
      $scope.inputNumber = '45.56.14';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual("Please enter proper input value.");
    });	
	
	it('it should return "Please enter proper input value." if the input number is abc', function() {
      $scope.inputNumber = 'abc';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual("Please enter proper input value.");
    });	
});