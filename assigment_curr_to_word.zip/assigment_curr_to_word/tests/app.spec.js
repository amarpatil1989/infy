describe('Test Controller', function() {
    beforeEach(angular.mock.module('myApp'));
	var $controller, $scope, controller;

  beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
  }));
    
    beforeEach(function() {
      $scope = {};
      controller = $controller('myCtrl', { $scope: $scope });
    });

    it('it should return One hundred Eleven  dollar if the input number is 111 and currency is dollar', function() {
      $scope.inputNumber = '111';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('One hundred Eleven  dollar');
    });

    it('it should return   Twelve crore Thirty  Four lakh Fifty  Six thousand Seven hundred Eighty  Nine  euro if the input number is 123456789 and currency is euro', function() {
      $scope.inputNumber = '123456789';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('  Twelve crore Thirty  Four lakh Fifty  Six thousand Seven hundred Eighty  Nine  euro');
    });
	
	it('it should return Seven hundred Eighty  Nine  dollar Ninety  Nine  cents if the input number is 789.99 and currency is dollar', function() {
      $scope.inputNumber = '789.99';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('     Seven hundred Eighty  Nine  dollar      Ninety  Nine  cents');
    });
	
	it('it should return Nine thousand One hundred Twenty  Three  dollar Fifty  Five  cents if the input number is 9,123.55 and currency is dollar', function() {
      $scope.inputNumber = '9,123.55';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('    Nine thousand One hundred Twenty  Three  dollar      Fifty  Five  cents');
    });
	
	it('it should return Fifty  Four thousand Three hundred Twenty  One  euro Ninety  Nine  cents if the input number is 5.4321,99 and currency is euro', function() {
      $scope.inputNumber = '5.4321,99';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual('    Fifty  Four thousand Three hundred Twenty  One  euro      Ninety  Nine  cents');
    });
	
	it('it should return "Please enter proper input value." if the input number is -123', function() {
      $scope.inputNumber = '-123';
      $scope.output = $scope.convert();
      expect($scope.output).toEqual("Please enter proper input value.");
    });	
});