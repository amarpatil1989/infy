var app = angular.module('myApp', []);
 
app.controller('myCtrl', function($scope) {
 
	var word = '';
	var decWord = '';
	$scope.output = "";
	
	$scope.convert = function() {
 
		$scope.amt = $scope.amount;
		$scope.int = $scope.myInt;
 
		if($scope.amt === undefined  || $scope.int === undefined ){
			alert("Enter amount or conversion");
		}else{
			var numberCheck = $scope.amt;
			var myNum = numberCheck.replace(",","");
			var myNum = myNum.replace(".","");
	
			if(isNaN(myNum) || myNum < 0){
				alert("Please enter proper input value.");
			}else{
				var curr ='';
				var tempArr='';
				var number ='';
				var decimal ='';
				var amount = $scope.amt;
				if($scope.int == 'euro'){
				 curr=' Euro';
				  myNum = amount.replace(".","#");
				  myNum = myNum.replace(",",".");
				  myNum = myNum.replace("#",",");
				  tempArr = myNum.split(".");
				  number = tempArr[0].split(",").join("");
				  decimal = tempArr[1];
				}else{
				curr=' Dollar';
				tempArr = amount.split(".");
					number = tempArr[0].split(",").join("");
					decimal = tempArr[1];
				}
				 if(number != 0){
					 wordConvert((number/1000000000)," Hundred");
					wordConvert((number/10000000)%100," Crore");
					wordConvert(((number/100000)%100)," Lakh");
					wordConvert(((number/1000)%100)," Thousand");
					wordConvert(((number/100)%10)," Hundred");
					wordConvert((number%100)," ");
					word = word + curr;
				 }
								 
				 if(decimal != undefined){
					decimal = decimal.slice(0,2);
					if(decimal != 0){
					wordConvert((decimal%100)," ");
					word = word +   " Cents"  ;
					}
				}
				return 	$scope.output=word;
			}
		}
	}
 
 
	function wordConvert(m,ch){
		var m = Math.trunc(m);
		var forUnits =[" "," One"," Two"," Three"," Four"," Five"," Six"," Seven"," Eight"," Nine"," Ten"," Eleven"," Twelve"," Thirteen"," Fourteen","Fifteen"," Sixteen"," Seventeen"," Eighteen"," Nineteen"];
		 
		var forTens =[" "," "," Twenty"," Thirty"," Forty"," Fifty"," Sixty","Seventy"," Eighty"," Ninety"];
		if(m > 19) 
		{ 
			word = word + forTens[Math.trunc(m/10)]+" "+forUnits[m%10];
		} 
		else 
		{
			word = word +forUnits[m];
		}
		if(m > 0)
			word = word + ch;
	}
  
});